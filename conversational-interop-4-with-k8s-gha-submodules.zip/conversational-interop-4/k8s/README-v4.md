# v4 Deployment Notes (banterop.fhir.me)

- Hostname: **banterop.fhir.me**
- Namespace: `interop`
- Deployment: `interop-api`
- Cert/secret names: `banterop-fhir-me` / `banterop-fhir-me-tls`
- ConfigMap `PUBLIC_API_BASE_URL=https://banterop.fhir.me/api`

See `../.github/workflows/deploy-v4.yml` for CI/CD details.
