import { test, expect } from "bun:test";

test("smoke", () => {
  expect(1 + 1).toBe(2);
});
