
import { Hono } from 'hono';
import { Database } from 'bun:sqlite';
import { createScenariosStore } from '../core/scenarios-store';
import { createScenariosRoutes } from '../routes/scenarios';
import { createLLMRoutes } from '../routes/llm';

/** Call from your server bootstrap to mount /api/scenarios and /api/llm */
export function installLLMAndScenarios(app: Hono, opts?: { dbPath?: string }) {
  const dbPath = opts?.dbPath || process.env.FLIPPROXY_DB || ':memory:';
  const db = new Database(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');

  const scenarios = createScenariosStore(db);
  app.route('/api/scenarios', createScenariosRoutes(scenarios));
  app.route('/api', createLLMRoutes());
}
